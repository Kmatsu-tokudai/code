
int func1( int argc );
int func2( int argc );
