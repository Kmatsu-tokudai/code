int func2( int argc )
{
  return argc * -1;
}
