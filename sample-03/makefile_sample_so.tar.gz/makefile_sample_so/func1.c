
int func1(int argc ){
  return argc * 2;
}
